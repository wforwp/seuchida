package kr.dureon.prototype

import android.app.Activity
import android.media.AudioAttributes
import android.media.AudioManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.util.Log
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private data class Scene(val id:String,val name:String,val category:String,val side:String,val start:Double,val end:Double,val intro:String,val detail:String)

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private val scenes=listOf(
        Scene("bulam","불암산","산과 자연","오른쪽",300.0,600.0,
            "오른쪽 산 풍경을 함께 바라봐요. 불암산을 주제로 준비한 시연용 이야기입니다. 실제 관찰 구간은 아직 연결하지 않았어요.",
            "바위 능선과 숲이 만드는 모양을 천천히 살펴보세요. 같은 산도 바라보는 방향과 계절에 따라 다른 모습을 보여줍니다. 이 이야기는 시연용 원고이며, 실제 노선 안내는 현장 검증 후 제공해요."),
        Scene("stream","중랑천","강과 다리","왼쪽",1000.0,1300.0,
            "왼쪽 물길을 함께 바라봐요. 중랑천을 주제로 준비한 시연용 이야기입니다. 창밖의 실제 위치와는 연결되지 않았어요.",
            "강가의 나무와 물 위에 비치는 빛을 찾아보세요. 물길을 따라 펼쳐지는 풍경은 도시에서 만나는 작은 쉼터가 됩니다. 이 화면의 풍경은 예시 이미지이며 실제 관찰 위치는 별도 검증이 필요해요."),
        Scene("surak","수락산","산과 자연","오른쪽",1800.0,2100.0,
            "오른쪽 능선의 모양을 찾아볼까요? 수락산을 주제로 준비한 시연용 이야기입니다. 실제 지피에스 위치를 사용하는 안내는 아니에요.",
            "능선을 손가락으로 따라 그린다고 상상해 보세요. 봉우리가 높아졌다 낮아지는 모습에서 어떤 모양이 떠오르나요? 함께 탄 가족과 이야기를 나눠 보세요. 장소 정보와 관찰 구간은 실제 서비스 전에 검수할 예정이에요.")
    )
    private val handler=Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("dureon",MODE_PRIVATE) }
    private lateinit var web:WebView
    private var pageReady=false
    private var destroyed=false
    private var tts:TextToSpeech?=null
    private var voices=listOf<Voice>()
    private var ttsReady=false
    private var speechState="음성 준비 중"
    private var speaking=false
    private var utteranceId=""
    private var sequence=0
    private var position=0.0
    private var speed=60
    private var forward=true
    private var running=false
    private var lastTick=0L
    private var current:Scene?=null
    private var narrationScene:Scene?=null
    private val announced=mutableSetOf<String>()
    private var history=JSONArray()
    private val audio by lazy { getSystemService(AudioManager::class.java) }
    private val tick=object:Runnable {
        override fun run(){
            if(destroyed)return
            if(running){
                val now=SystemClock.elapsedRealtime()
                val dt=(now-lastTick).coerceIn(0L,1000L)/1000.0
                lastTick=now
                position=(position+(if(forward)1 else -1)*speed/3.6*dt).coerceIn(0.0,2400.0)
                selectScene()
                if((forward&&position>=2400.0)||(!forward&&position<=0.0)) running=false
            }
            publish();handler.postDelayed(this,400)
        }
    }
    override fun onCreate(savedInstanceState:Bundle?){
        super.onCreate(savedInstanceState)
        volumeControlStream=AudioManager.STREAM_MUSIC
        if(prefs.getBoolean("saveHistory",false)) history=runCatching { JSONArray(prefs.getString("history","[]")) }.getOrDefault(JSONArray())
        if(savedInstanceState!=null){
            position=savedInstanceState.getDouble("position");speed=savedInstanceState.getInt("speed",60);forward=savedInstanceState.getBoolean("forward",true)
            current=scenes.find { it.id==savedInstanceState.getString("current") }
            announced.addAll(savedInstanceState.getStringArrayList("announced")?:emptyList())
            if(!prefs.getBoolean("saveHistory",false)) history=runCatching{JSONArray(savedInstanceState.getString("history","[]"))}.getOrDefault(JSONArray())
        }
        window.statusBarColor=android.graphics.Color.rgb(17,25,22)
        window.navigationBarColor=android.graphics.Color.rgb(17,25,22)
        web=WebView(this);web.setBackgroundColor(android.graphics.Color.rgb(17,25,22))
        web.setOnApplyWindowInsetsListener { view,insets ->
            view.setPadding(insets.systemWindowInsetLeft,insets.systemWindowInsetTop,insets.systemWindowInsetRight,insets.systemWindowInsetBottom)
            insets
        }
        WebView.setWebContentsDebuggingEnabled(applicationInfo.flags and android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE != 0)
        web.settings.javaScriptEnabled=true;web.settings.domStorageEnabled=true;web.settings.allowFileAccess=false;web.settings.allowContentAccess=false
        web.addJavascriptInterface(Bridge(),"DureonNative")
        web.webViewClient=object:WebViewClient(){
            override fun shouldOverrideUrlLoading(view:WebView,request:WebResourceRequest)=true
            override fun shouldInterceptRequest(view:WebView,request:WebResourceRequest):WebResourceResponse {
                val uri=request.url
                if(uri.scheme!="https"||uri.host!="appassets.androidplatform.net")return denied()
                val path=uri.path?.removePrefix("/")?:return denied()
                if(path !in setOf("index.html","style.css","app.js","landscape.png","scenery-example.jpg","fonts/PretendardVariable.woff2","brand/logo-dark.svg","brand/logo-light.svg"))return denied()
                return try {
                    val mime=when(path.substringAfterLast('.')){"html"->"text/html";"css"->"text/css";"js"->"application/javascript";"woff2"->"font/woff2";"svg"->"image/svg+xml";"jpg"->"image/jpeg";else->"image/png"}
                    WebResourceResponse(mime,"UTF-8",assets.open(path))
                }catch(_:Exception){denied()}
            }
            override fun onPageFinished(view:WebView,url:String){pageReady=true;publish()}
        }
        setContentView(web);web.loadUrl("https://appassets.androidplatform.net/index.html")
        tts=TextToSpeech(this,this);handler.post(tick)
    }
    private fun denied()=WebResourceResponse("text/plain","UTF-8",403,"Blocked",emptyMap(),"".byteInputStream())
    inner class Bridge {
        @JavascriptInterface fun action(name:String,payload:String){handler.post {
            if(!destroyed){runCatching{handle(name,JSONObject(payload))}.onFailure{Log.e("Dureon","Invalid action: $name",it)};publish()}
        }}
    }
    private fun handle(name:String,p:JSONObject){
        when(name){
            "ready"->publish()
            "toggle"->{if(!running&&((forward&&position>=2400)||(!forward&&position<=0)))reset();running=!running;lastTick=SystemClock.elapsedRealtime();if(!running)stopSpeech()}
            "pause"->{running=false;stopSpeech()}
            "reset"->reset()
            "direction"->{forward=!forward;announced.clear();current=null;stopSpeech();lastTick=SystemClock.elapsedRealtime()}
            "speed"->{val value=p.optInt("value");if(value in listOf(0,30,60,100))speed=value}
            "stop"->stopSpeech()
            "more"->{val s=current;if(s!=null)say(s.detail,s) else say("아직 함께 본 풍경이 없어요. 함께 달리기를 시작해 주세요.")}
            "replay"->{val s=current;if(s!=null)say(storyText(s),s) else say("아직 들은 이야기가 없어요. 먼저 이야기를 선택해 주세요.")}
            "preview"->{val s=scenes.find{it.id==p.optString("id")};if(s!=null)say(if(p.optBoolean("detail"))s.detail else s.intro,s)}
            "test"->say("안녕하세요. 스치다입니다. 창밖 풍경이 이야기가 되는 시간, 함께 떠나볼까요?")
            "volume"->audio.setStreamVolume(AudioManager.STREAM_MUSIC,p.optInt("value").coerceIn(0,audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)),0)
            "voice"->{val voice=voices.find{it.name==p.optString("value")};if(voice!=null){stopSpeech();tts?.voice=voice;prefs.edit().putString("voice",voice.name).apply()}}
            "pace"->{val value=p.optString("value");if(value in listOf("relaxed","often"))prefs.edit().putString("pace",value).apply()}
            "saveHistory"->{val enabled=p.optBoolean("value");prefs.edit().putBoolean("saveHistory",enabled).apply();if(enabled)persistHistory()else prefs.edit().remove("history").apply()}
            "clearHistory"->{history=JSONArray();prefs.edit().remove("history").apply()}
        }
    }
    private fun reset(){running=false;position=if(forward)0.0 else 2400.0;announced.clear();current=null;stopSpeech()}
    private fun storyText(s:Scene):String {
        if(position>s.end&&forward||position<s.start&&!forward)return "앞서 함께 본 ${s.name} 이야기예요. ${s.detail}"
        if(position in s.start..s.end)return "지금은 ${s.name}의 가상 관찰 구간이에요. ${s.intro}"
        if(!forward)return "반대 방향에서 만나는 ${s.name}의 시연용 이야기예요. 실제 좌우 방향은 현장 검증 전입니다."
        return s.intro
    }
    private fun selectScene(){
        if(speed==0||speaking||!ttsReady)return
        val gap=if(prefs.getString("pace","relaxed")=="relaxed")250.0 else 0.0
        val candidate=(if(forward)scenes else scenes.reversed()).firstOrNull { s->
            val d=if(forward)s.start-position else position-s.end
            "${s.id}:$forward" !in announced&&((d>=0&&d/(speed/3.6)<=5.0)||position in s.start..s.end)&&
                scenes.none { other->other.id!=s.id&&"${other.id}:$forward" in announced&&(if(forward)position-other.end else other.start-position) in 0.0..gap }
        }
        if(candidate!=null){current=candidate;say(storyText(candidate),candidate,true)}
    }
    private fun say(text:String,scene:Scene?=null,automatic:Boolean=false){
        if(!ttsReady){speechState="한국어 음성을 준비하고 있어요";return}
        val id="story-${++sequence}";utteranceId=id;narrationScene=scene
        val result=tts?.speak(text,TextToSpeech.QUEUE_FLUSH,Bundle().apply{putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME,1f)},id)
        if(result==TextToSpeech.SUCCESS){speechState="재생 준비 중";speaking=true;if(automatic&&scene!=null)announced.add("${scene.id}:$forward")}
        else {speaking=false;speechState="음성 재생을 시작하지 못했어요"}
    }
    private fun stopSpeech(){utteranceId="";tts?.stop();speaking=false;speechState=if(ttsReady)"잠시 쉬는 중" else "음성 준비 중"}
    override fun onInit(status:Int){
        if(destroyed)return
        ttsReady=status==TextToSpeech.SUCCESS&&(tts?.setLanguage(Locale.KOREAN)?:-1)>=0
        voices=tts?.voices?.filter{it.locale.language=="ko"}?.sortedWith(compareBy<Voice>{it.isNetworkConnectionRequired}.thenBy{it.name})?:emptyList()
        voices.find{it.name==prefs.getString("voice","")}?.let{tts?.voice=it}
        tts?.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
        speechState=if(ttsReady)"음성 준비됨" else "한국어 음성 엔진을 확인해 주세요"
        tts?.setOnUtteranceProgressListener(object:UtteranceProgressListener(){
            override fun onStart(id:String?){handler.post{if(id==utteranceId&&!destroyed){speaking=true;speechState="이야기 재생 중";narrationScene?.let{record(it)};publish();Log.i("DureonSpeech","Started $id")}}}
            override fun onDone(id:String?){finish(id,"이야기 재생 완료")}
            @Deprecated("Legacy callback") override fun onError(id:String?){finish(id,"음성을 재생하지 못했어요")}
            override fun onError(id:String?,errorCode:Int){finish(id,"음성 오류 ($errorCode) · 설정에서 음성을 확인해 주세요")}
            override fun onStop(id:String?,interrupted:Boolean){finish(id,"음성 중단됨")}
        });publish()
    }
    private fun finish(id:String?,message:String){handler.post{if(id==utteranceId&&!destroyed){speaking=false;speechState=message;publish();Log.i("DureonSpeech","$message $id")}}}
    private fun record(scene:Scene){
        val entry=JSONObject().put("id",scene.id).put("time",SimpleDateFormat("HH:mm",Locale.KOREA).format(Date())).put("date",SimpleDateFormat("yyyy.MM.dd",Locale.KOREA).format(Date())).put("stamp",System.currentTimeMillis())
        val next=JSONArray().put(entry);for(i in 0 until minOf(history.length(),49))next.put(history.getJSONObject(i));history=next
        if(prefs.getBoolean("saveHistory",false))persistHistory()
    }
    private fun persistHistory(){prefs.edit().putString("history",history.toString()).apply()}
    private fun publish(){
        if(!pageReady||destroyed)return
        val json=JSONObject().put("position",position.toInt()).put("speed",speed).put("forward",forward).put("running",running)
            .put("current",current?.id?:JSONObject.NULL).put("speaking",speaking).put("speechState",speechState).put("ttsReady",ttsReady)
            .put("volume",audio.getStreamVolume(AudioManager.STREAM_MUSIC)).put("maxVolume",audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC))
            .put("voice",tts?.voice?.name?:"").put("saveHistory",prefs.getBoolean("saveHistory",false)).put("pace",prefs.getString("pace","relaxed"))
            .put("history",history).put("scenes",JSONArray(scenes.map{s->JSONObject().put("id",s.id).put("name",s.name).put("category",s.category).put("side",s.side).put("intro",s.intro).put("detail",s.detail).put("start",s.start).put("end",s.end)}))
            .put("voices",JSONArray(voices.mapIndexed{i,v->JSONObject().put("id",v.name).put("label","한국어 음성 ${i+1} · ${if(v.isNetworkConnectionRequired)"온라인" else "기기 음성"}")}))
        web.evaluateJavascript("window.receiveState && window.receiveState($json)",null)
    }
    override fun onSaveInstanceState(outState:Bundle){
        outState.putDouble("position",position);outState.putInt("speed",speed);outState.putBoolean("forward",forward)
        outState.putString("current",current?.id);outState.putStringArrayList("announced",ArrayList(announced));outState.putString("history",history.toString());super.onSaveInstanceState(outState)
    }
    override fun onPause(){super.onPause();running=false;stopSpeech();publish()}
    override fun onResume(){super.onResume();publish()}
    override fun onDestroy(){destroyed=true;handler.removeCallbacksAndMessages(null);tts?.stop();tts?.shutdown();web.removeJavascriptInterface("DureonNative");web.destroy();super.onDestroy()}
}
