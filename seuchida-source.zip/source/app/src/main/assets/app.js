/* All UI assets are packaged locally. Only DureonNative can control device audio. */
'use strict';
// Lucide 0.468.0 SVG paths; see licenses/Lucide-LICENSE.txt.
const icons={"car": "<path d=\"m21 8-2 2-1.5-3.7A2 2 0 0 0 15.646 5H8.4a2 2 0 0 0-1.903 1.257L5 10 3 8\" />\n  <path d=\"M7 14h.01\" />\n  <path d=\"M17 14h.01\" />\n  <rect width=\"18\" height=\"8\" x=\"3\" y=\"10\" rx=\"2\" />\n  <path d=\"M5 18v2\" />\n  <path d=\"M19 18v2\" />\n", "book": "<path d=\"M12 7v14\" />\n  <path d=\"M3 18a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h5a4 4 0 0 1 4 4 4 4 0 0 1 4-4h5a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1h-6a3 3 0 0 0-3 3 3 3 0 0 0-3-3z\" />\n", "bookmark": "<path d=\"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8\" />\n  <path d=\"M3 3v5h5\" />\n  <path d=\"M12 7v5l4 2\" />\n", "settings": "<path d=\"M20 7h-9\" />\n  <path d=\"M14 17H5\" />\n  <circle cx=\"17\" cy=\"17\" r=\"3\" />\n  <circle cx=\"7\" cy=\"7\" r=\"3\" />\n", "play": "<polygon points=\"6 3 20 12 6 21 6 3\" />\n", "pause": "<rect x=\"14\" y=\"4\" width=\"4\" height=\"16\" rx=\"1\" />\n  <rect x=\"6\" y=\"4\" width=\"4\" height=\"16\" rx=\"1\" />\n", "replay": "<path d=\"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8\" />\n  <path d=\"M3 3v5h5\" />\n", "stop": "<rect width=\"18\" height=\"18\" x=\"3\" y=\"3\" rx=\"2\" />\n", "mic": "<path d=\"M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z\" />\n  <path d=\"M19 10v2a7 7 0 0 1-14 0v-2\" />\n  <line x1=\"12\" x2=\"12\" y1=\"19\" y2=\"22\" />\n", "pin": "<path d=\"M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0\" />\n  <circle cx=\"12\" cy=\"10\" r=\"3\" />\n", "download": "<path d=\"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4\" />\n  <polyline points=\"7 10 12 15 17 10\" />\n  <line x1=\"12\" x2=\"12\" y1=\"15\" y2=\"3\" />\n", "arrow": "<path d=\"m9 18 6-6-6-6\" />\n", "check": "<path d=\"M20 6 9 17l-5-5\" />\n", "info": "<circle cx=\"12\" cy=\"12\" r=\"10\" />\n  <path d=\"M12 16v-4\" />\n  <path d=\"M12 8h.01\" />\n"};
const icon=n=>`<svg class="ui-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false">${icons[n]||icons.info}</svg>`;
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const menus=[['drive','car','주행 안내'],['stories','book','이야기'],['history','bookmark','청취 기록'],['settings','settings','설정']];
let state=null,menu='drive',filter='전체',selected='bulam',detail=false,lastKey='',toastTimer;
const $=s=>document.querySelector(s);
let theme='dark', demoOpen=false;
try { theme=localStorage.getItem('seuchida-theme')==='light'?'light':'dark'; } catch {}
function setTheme(value){
 theme=value==='light'?'light':'dark';
 document.documentElement.dataset.theme=theme;
 const logo=document.querySelector('.brand-logo');if(logo)logo.src=`brand/logo-${theme}.svg`;
 document.querySelector('meta[name="theme-color"]').content=theme==='light'?'#edf1e9':'#111916';
 try { localStorage.setItem('seuchida-theme',theme); } catch {}
 document.querySelectorAll('[data-theme-choice]').forEach(b=>{const active=b.dataset.themeChoice===theme;b.classList.toggle('active',active);b.setAttribute('aria-pressed',String(active));});
}
setTheme(theme);
document.addEventListener('toggle',e=>{if(e.target.matches?.('.demo-panel'))demoOpen=e.target.open;},true);
function send(name,payload={}){if(window.DureonNative)window.DureonNative.action(name,JSON.stringify(payload));else toast('Android 앱에서 사용할 수 있어요.');}
function button(label,action,ic,cls='',extra=''){return `<button class="button ${cls}" data-action="${action}" ${extra}>${ic?icon(ic):''}${label}</button>`;}
function switchControl(key,checked,label){return `<label class="switch"><input type="checkbox" data-setting="${key}" aria-label="${label}" ${checked?'checked':''}><span></span></label>`;}
function navigate(next){if(!menus.some(m=>m[0]===next))return;if(next!==menu&&next!=='drive'&&state?.running){send('pause');toast('이야기 둘러보기를 위해 가상 주행을 일시정지했어요.');}menu=next;lastKey='';render();document.querySelector('#content').scrollTop=0;}
window.receiveState=s=>{state=s;render();};
function render(){
 if(!state)return;
 const key=JSON.stringify([menu,state.current,state.running,state.forward,state.history.length,state.history[0]?.stamp,state.saveHistory,state.pace,state.voices,state.voice,filter,selected,detail]);
 if(lastKey!==key){lastKey=key;renderNav();renderHeader();$('#content').innerHTML=({drive:drive,stories:stories,history:history,settings:settings})[menu]();}
 updateLive();
}
function renderNav(){$('#navigation').innerHTML=menus.map(([id,ic,label])=>`<button class="nav-item ${id===menu?'active':''}" data-nav="${id}" ${id===menu?'aria-current="page"':''}>${icon(ic)}<span>${label}</span></button>`).join('');}
function renderHeader(){const m=menus.find(x=>x[0]===menu);$('#topbar').innerHTML=`<h1>${m[2]}</h1><div class="header-info"><span class="status-mark ${state.running?'active':''}"></span>${state.running?'가상 주행 중':'가상 주행'} · GPS 미연동</div>`;}
function drive(){return `<div class="drive-hero"><div class="hero-top"><span class="route-label">시연 노선 · 2.4 km · 배경 사진은 예시</span><div class="speed"><strong id="speed">60</strong><span>km/h</span></div></div><div class="hero-copy"><div class="scene-category" id="scene-category"></div><h2 id="scene-title"></h2><p id="scene-subtitle"></p></div><div class="listening" id="listening"><small>음성 안내</small><h3 id="listening-title"></h3><p class="speech-label" id="speech-state"></p></div></div><div class="actions">${button(state.running?'일시정지':'주행 시작','toggle',state.running?'pause':'play','toggle-drive')}${button('더 듣기','more','book')}${button('다시 듣기','replay','replay')}${button('중단','stop','stop')}</div><div class="trip-line"><span id="direction-label"></span><div class="track"><i id="track-fill"></i></div><span id="distance-label"></span></div><details class="demo-panel" ${demoOpen?'open':''}><summary>시연 설정<span>속도 · 방향</span></summary><div class="demo-controls">${[0,30,60,100].map(v=>button(v===0?'정차':`${v} km/h`,'speed',null,'small',`data-value="${v}"`)).join('')}${button('방향 전환','direction',null,'small')}${button('처음으로','reset',null,'small')}</div><p class="section-note">가상 노선에서 안내를 시험합니다. 실제 위치·내비게이션은 연결 전입니다.</p></details>`;}
function updateLive(){
 document.querySelectorAll('#speech-state,.current-speech').forEach(el=>el.textContent=state.speechState);
 if(menu==='drive'){
  const scene=state.scenes.find(s=>s.id===state.current);
  $('#speed').textContent=state.speed;
  $('#scene-title').textContent=scene?scene.name:state.running?'다음 풍경을 찾고 있어요':'주행을 시작하세요';
  let phase='잠시 뒤';
  if(scene){phase=state.position>=scene.start&&state.position<=scene.end?'함께 보는 중':(state.forward?state.position>scene.end:state.position<scene.start)?'지나온 풍경':'잠시 뒤';}
  $('#scene-category').textContent=scene?`${phase} · ${state.forward?scene.side:'반대 방향'} · 시연`:state.running?'자동 안내 중':'풍경 이야기';
  $('#scene-subtitle').textContent=scene?'창밖의 풍경을 소리로 만나보세요.':state.running?'조망 구간에 도착하면 이야기를 들려드립니다.':'풍경을 지나는 순간, 이야기가 시작됩니다.';
  $('#listening-title').textContent=state.speaking?'재생 중':scene?'재생 준비':'안내 대기';
  $('#listening').classList.toggle('speaking',state.speaking);
  $('#direction-label').textContent=state.forward?'정방향':'반대 방향';
  $('#distance-label').textContent=`${state.position.toLocaleString()} / 2,400 m`;
  $('#track-fill').style.width=`${(state.forward?state.position:2400-state.position)/24}%`;
  document.querySelectorAll('[data-action="speed"]').forEach(el=>el.classList.toggle('selected',Number(el.dataset.value)===state.speed));
 }
 if(menu==='settings'){
  const slider=$('#volume');if(slider&&document.activeElement!==slider)slider.value=state.volume;
  if($('#volume-value'))$('#volume-value').textContent=`${state.volume}/${state.maxVolume}`;
 }
}
function stories(){
 const list=state.scenes.filter(s=>filter==='전체'||s.category===filter);
 if(list.length&&!list.some(s=>s.id===selected))selected=list[0].id;
 const s=state.scenes.find(s=>s.id===selected);
 return `<div class="filters">${['전체','산과 자연','강과 다리'].map(f=>`<button class="filter ${filter===f?'active':''}" data-filter="${f}">${f}</button>`).join('')}</div><div class="scene-grid">${list.map(s=>`<button class="scene-tile ${s.id} ${s.id===selected?'selected':''}" data-scene="${s.id}" aria-label="${s.name} 선택"><small>${s.category} · 시연 원고</small><strong>${s.name}</strong></button>`).join('')}</div><article class="story-detail"><div class="detail-header"><div><h2>${s.name}</h2><span class="muted">${s.category} · 가족용 이야기</span></div><div class="setting-control">${button('미리 듣기','preview','play','primary',`data-id="${s.id}" data-detail="${detail}"`)}${button('중단','stop','stop','small')}</div></div><p class="section-note current-speech"></p><div class="story-tabs"><button class="story-tab ${!detail?'active':''}" data-detail="false">기본 이야기</button><button class="story-tab ${detail?'active':''}" data-detail="true">더 듣기</button></div><p class="story-script">${esc(detail?s.detail:s.intro)}</p><div class="notice">시연용 원고입니다. 실제 조망 구간과 내용 출처는 검증 전입니다.</div></article><p class="section-note">${icon('info')} 주행 중에는 자동 안내를 이용하고, 이야기 탐색은 정차 후 사용해 주세요.</p>`;
}
function history(){return `<div class="history-top"><div class="history-count">들은 이야기 <strong>${state.history.length}개</strong></div><div class="setting-control"><span class="muted">기기에 기록 저장</span>${switchControl('saveHistory',state.saveHistory,'기기에 기록 저장')}</div></div>${state.history.length?`<div class="history-list">${state.history.map(h=>{const s=state.scenes.find(s=>s.id===h.id);if(!s)return '';return `<article class="history-item ${s.id}"><div class="history-symbol" aria-hidden="true">${icon('book')}</div><div><h3>${s.name}</h3><time>${h.date} · ${h.time}</time></div>${button('다시 듣기','preview','play','small',`data-id="${s.id}"`)}</article>`}).join('')}</div><div class="demo-controls">${button('이야기 출처 안내','sources','book','small')}${button('기록 비우기','clearHistory',null,'small danger')}</div>`:`<div class="empty">${icon('bookmark')}<h2>첫 이야기를 기다리고 있어요</h2><p>함께 달리거나 이야기를 미리 들으면<br>이곳에 청취 기록이 쌓여요.</p>${button('이야기 둘러보기','browse','book','primary')}</div>`}<p class="section-note">${state.saveHistory?'기록을 이 기기에 저장하고 있어요. 저장을 끄면 기기에 저장된 기록을 지웁니다.':'현재 이용 중인 청취 기록만 보여요. 앱을 종료한 뒤에도 보려면 기기에 기록 저장을 켜 주세요.'} 위치 이동 경로와 음성 원본은 저장하지 않습니다.</p>`;}
function settings(){return `<div class="settings-card"><div class="setting-row"><div class="setting-label"><h3>화면 테마</h3><p>주변 밝기에 맞게 직접 선택합니다.</p></div><div class="setting-control segments" aria-label="화면 테마">${[['dark','어둡게'],['light','밝게']].map(([v,t])=>`<button class="${theme===v?'active':''}" aria-pressed="${theme===v}" data-theme-choice="${v}">${t}</button>`).join('')}</div></div><div class="setting-row"><div class="setting-label"><h3>안내 음성</h3><p>기기에 제공되는 한국어 TTS 음성이에요.</p></div><div class="setting-control"><select id="voice" aria-label="한국어 목소리 선택" ${!state.voices.length?'disabled':''}>${state.voices.length?state.voices.map(v=>`<option value="${esc(v.id)}" ${state.voice===v.id?'selected':''}>${esc(v.label)}</option>`).join(''):'<option>음성 준비 중</option>'}</select>${button('미리 듣기','test','play','small')}</div></div><div class="setting-row"><div class="setting-label"><h3>음량</h3><p>에뮬레이터의 미디어 볼륨을 조절해요.</p></div><div class="setting-control"><input id="volume" type="range" min="0" max="${state.maxVolume}" value="${state.volume}" aria-label="미디어 음량"><span id="volume-value" class="volume-value"></span></div></div><div class="setting-row"><div class="setting-label"><h3>안내 빈도</h3><p>이야기 사이에 여유를 두고 안내할까요?</p></div><div class="setting-control segments">${[['relaxed','여유롭게'],['often','자주']].map(([v,t])=>`<button class="${state.pace===v?'active':''}" data-pace="${v}">${t}</button>`).join('')}</div></div><div class="setting-row toggle-row"><div class="setting-label"><h3>기기에 청취 기록 저장</h3><p>들은 이야기 목록을 다음에도 볼 수 있어요.</p></div>${switchControl('saveHistory',state.saveHistory,'청취 기록 저장')}</div><div class="setting-row"><div class="setting-label"><h3>이야기 유형</h3><p>현재는 미리 준비한 가족용 원고를 제공해요.</p></div><span class="pill live">가족</span></div><div class="setting-row"><div class="setting-label"><h3>GPS · 기본 내비게이션</h3><p>실제 위치·경로 연동은 준비 중이에요.</p></div><span class="pill demo">미연동</span></div></div><div class="link-cards">${button('포함된 이야기 3개','included','download','',`aria-label="포함된 이야기 안내"`)}${button('음성 명령 · 준비 중','commands','mic')}${button('앱 정보 · 권한','about','info')}</div><p class="section-note current-speech"></p>`;}
function toast(text){const t=$('#toast');t.textContent=text;t.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>t.classList.remove('show'),3500);}
function modal(title,html){$('#modal-content').innerHTML=`<h2>${title}</h2>${html}`;$('#modal').showModal();}
$('#close-modal').addEventListener('click',()=>$('#modal').close());
document.addEventListener('click',e=>{
 const themeButton=e.target.closest('[data-theme-choice]');if(themeButton){setTheme(themeButton.dataset.themeChoice);return;}
 const nav=e.target.closest('[data-nav]');if(nav){navigate(nav.dataset.nav);return;}
 const f=e.target.closest('[data-filter]');if(f){filter=f.dataset.filter;lastKey='';render();return;}
 const scene=e.target.closest('[data-scene]');if(scene){selected=scene.dataset.scene;lastKey='';render();return;}
 const tab=e.target.closest('.story-tab');if(tab){detail=tab.dataset.detail==='true';lastKey='';render();return;}
 const pace=e.target.closest('[data-pace]');if(pace){send('pace',{value:pace.dataset.pace});return;}
 const b=e.target.closest('[data-action]');if(!b)return;
 const action=b.dataset.action;
 if(action==='speed'){send('speed',{value:Number(b.dataset.value)});return;}
 if(action==='preview'){send('preview',{id:b.dataset.id,detail:b.dataset.detail==='true'});return;}
 if(action==='browse'){navigate('stories');return;}
 if(action==='commands'){modal('음성 명령은 준비 중이에요','<p>지금은 화면 버튼으로 더 듣기·다시 듣기·음성 중단을 사용할 수 있어요. 마이크 인식은 아직 연결하지 않았습니다.</p>');return;}
 if(action==='sources'){modal('이야기 출처 안내','<p>현재 세 이야기는 화면과 재생 기능을 확인하는 시연용 원고입니다. 실제 장소의 검수된 해설과 출처는 아직 등록하지 않았어요.</p>');return;}
 if(action==='included'){modal('포함된 이야기','<ul class="fact-list"><li><strong>불암산 · 중랑천 · 수락산</strong>가족용 기본 이야기와 더 듣기 원고가 앱에 포함돼 있어요.</li><li><strong>오프라인 콘텐츠</strong>이야기 목록과 원고는 인터넷 없이 볼 수 있어요. 음성은 선택한 기기 엔진의 지원 여부에 따라 달라집니다.</li></ul>');return;}
 if(action==='about'){modal('스치다 · 시연 버전','<ul class="fact-list"><li><strong>가상 노선 2.4km</strong>실제 GPS·내비·마이크는 미연동 상태예요.</li><li><strong>위치 · 마이크 권한</strong>현재 앱은 위치와 마이크 권한을 요청하지 않아요.</li><li><strong>시연 콘텐츠</strong>등록된 가상 구간과 시연 원고를 사용합니다. 실제 장소의 조망 구간은 검증 전입니다.</li><li><strong>글꼴 · 아이콘</strong>본문 Pretendard 1.3.9 · 로고 나눔손글씨 펜 · Lucide 0.468.0. 라이선스 고지를 앱에 포함했습니다.</li><li><strong>배경 사진</strong>월악산과 충주호 · Ashy Minivet · CC0 1.0. 시연용 예시 사진이며 현재 안내 장소와 다릅니다.</li><li><strong>앱 버전 0.11</strong>창밖 풍경이 이야기가 되는 시간</li></ul>');return;}
 if(action==='clearHistory'){modal('청취 기록을 비울까요?',`<p>현재 목록과 기기에 저장된 청취 기록을 지웁니다.</p>${button('기록 비우기','confirmClear',null,'danger')}`);return;}
 if(action==='confirmClear'){send('clearHistory');$('#modal').close();toast('청취 기록을 비웠어요.');return;}
 send(action);
});
document.addEventListener('change',e=>{if(e.target.id==='voice')send('voice',{value:e.target.value});if(e.target.id==='volume')send('volume',{value:Number(e.target.value)});if(e.target.dataset.setting==='saveHistory')send('saveHistory',{value:e.target.checked});});
document.addEventListener('input',e=>{if(e.target.id==='volume')$('#volume-value').textContent=`${e.target.value}/${state.maxVolume}`;});
window.addEventListener('hashchange',()=>navigate(location.hash.slice(1)));
send('ready');
