import {execFileSync} from 'node:child_process';
import {writeFileSync,mkdirSync} from 'node:fs';
import {resolve} from 'node:path';
const serial=process.argv[2]||'emulator-5560';
const adb=(...a)=>execFileSync('C:/Users/outset/AppData/Local/Android/Sdk/platform-tools/adb.exe',['-s',serial,...a],{encoding:'utf8'}).trim();
const out=resolve('..','docs','design','screenshots-photo-2026-11-15');mkdirSync(out,{recursive:true});
const pid=adb('shell','pidof','kr.dureon.prototype');adb('forward','tcp:9232',`localabstract:webview_devtools_remote_${pid}`);
const pages=await(await fetch('http://127.0.0.1:9232/json/list')).json();
const socket=new WebSocket(pages.find(p=>p.url.includes('appassets')).webSocketDebuggerUrl);
await new Promise((r,j)=>{socket.onopen=r;socket.onerror=j});
let n=0;const requests=new Map();
socket.onmessage=e=>{const m=JSON.parse(e.data);if(m.id){const p=requests.get(m.id);if(p){clearTimeout(p.timer);requests.delete(m.id);m.error?p.reject(Error(JSON.stringify(m.error))):p.resolve(m.result);}}};
const call=(method,params={})=>new Promise((resolve,reject)=>{const id=++n;const timer=setTimeout(()=>reject(Error(method)),10000);requests.set(id,{resolve,reject,timer});socket.send(JSON.stringify({id,method,params}));});
const evaluate=async expression=>{const r=await call('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});if(r.exceptionDetails)throw Error(JSON.stringify(r.exceptionDetails));return r.result.value;};
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
try{
 await call('Runtime.enable');await call('Page.enable');
 await evaluate(`send('pause');filter='전체';selected='bulam';detail=false;navigate('drive')`);await sleep(500);
 const bounds=await evaluate(`(()=>{const a=document.querySelector('.speed').getBoundingClientRect(),b=document.querySelector('.listening').getBoundingClientRect(),c=document.querySelector('.toggle-drive').getBoundingClientRect();return {speedVisible:!(a.left<b.right&&a.right>b.left&&a.top<b.bottom&&a.bottom>b.top),mainActionVisible:c.bottom<=innerHeight,overflow:document.documentElement.scrollWidth>innerWidth,viewport:[innerWidth,innerHeight]}})()`);
 if(!bounds.speedVisible||!bounds.mainActionVisible||bounds.overflow)throw Error(JSON.stringify(bounds));
 for(const [menu,name]of [['drive','01-drive-landscape'],['stories','02-stories-landscape'],['history','03-history-landscape'],['settings','04-settings-landscape']]){
  await evaluate(`navigate('${menu}')`);await sleep(400);
  const r=await call('Page.captureScreenshot',{format:'png',captureBeyondViewport:false});writeFileSync(resolve(out,name+'.png'),Buffer.from(r.data,'base64'));
 }
 await evaluate(`navigate('drive')`);
 console.log(JSON.stringify({layout:bounds,screenshots:out}));
}finally{socket.close()}

