import {execFileSync} from 'node:child_process';
import {mkdirSync,writeFileSync} from 'node:fs';
import {resolve} from 'node:path';
const serial=process.argv[2]||'emulator-5560';
const out=resolve(process.argv[3]||'../docs/verification/2026-11-14');mkdirSync(out,{recursive:true});
const adb=(...a)=>execFileSync('C:/Users/outset/AppData/Local/Android/Sdk/platform-tools/adb.exe',['-s',serial,...a],{encoding:'utf8'}).trim();
let socket,sequence=0;const requests=new Map();
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const call=(method,params={})=>new Promise((resolve,reject)=>{const id=++sequence;const timer=setTimeout(()=>reject(Error(method)),15000);requests.set(id,{resolve,reject,timer});socket.send(JSON.stringify({id,method,params}));});
async function evaluate(expression){const r=await call('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});if(r.exceptionDetails)throw Error(JSON.stringify(r.exceptionDetails));return r.result.value;}
async function connect(){
 const pid=adb('shell','pidof','kr.dureon.prototype');adb('forward','tcp:9234',`localabstract:webview_devtools_remote_${pid}`);
 let target;
 for(let i=0;i<40;i++){try{const pages=await(await fetch('http://127.0.0.1:9234/json/list')).json();target=pages.find(p=>p.url.includes('appassets'));if(target)break;}catch{}await sleep(250);}
 if(!target)throw Error('WebView unavailable');
 socket=new WebSocket(target.webSocketDebuggerUrl);await new Promise((r,j)=>{socket.onopen=r;socket.onerror=j});
 socket.onmessage=e=>{const m=JSON.parse(e.data);const p=requests.get(m.id);if(p){clearTimeout(p.timer);requests.delete(m.id);m.error?p.reject(Error(JSON.stringify(m.error))):p.resolve(m.result);}};
 await call('Runtime.enable');
 for(let i=0;i<60;i++){try{if(await evaluate(`typeof state!=='undefined'&&state&&typeof theme!=='undefined'&&state.ttsReady`))return;}catch{}await sleep(250);}
 throw Error('Application/TTS did not initialize');
}
const snapshot=`({saveHistory:state.saveHistory,historyStamps:state.history.map(h=>h.stamp),pace:state.pace,voice:state.voice,theme,volume:state.volume})`;
const checks=[];
function check(value,label){if(!value)throw Error(label);checks.push(label);console.log('PASS '+label);}
try{
 await connect();
 const before=await evaluate(snapshot);
 // Inspect placeholder functions and a destructive action without confirming deletion.
 await evaluate(`navigate('settings');document.querySelector('[data-action="commands"]').click()`);
 check(await evaluate(`document.querySelector('#modal').open&&document.querySelector('#modal-content').textContent.includes('아직 연결하지 않았습니다')`),'Voice command menu clearly reports microphone is not connected');
 await evaluate(`document.querySelector('#close-modal').click();navigate('history')`);
 if(await evaluate(`!!document.querySelector('[data-action="clearHistory"]')`)){
  await evaluate(`document.querySelector('[data-action="clearHistory"]').click()`);
  check(await evaluate(`document.querySelector('#modal').open&&!!document.querySelector('[data-action="confirmClear"]')`),'Clearing history requires confirmation');
  await evaluate(`document.querySelector('#close-modal').click()`);
  check(JSON.stringify(await evaluate('state.history.map(h=>h.stamp)'))===JSON.stringify(before.historyStamps),'Dismissing clear-history dialog preserves existing records');
 }
 await evaluate(`navigate('drive');document.querySelector('.toggle-drive').click();send('test')`);
 let started=false;
 for(let i=0;i<40;i++){if(await evaluate(`state.running&&state.speaking&&state.speechState==='이야기 재생 중'`)){started=true;break;}await sleep(250);}
 check(started,'Simulation and TTS start before background test');
 await evaluate(`navigate('stories')`);
 for(let i=0;i<40;i++){if(await evaluate('!state.running&&!state.speaking'))break;await sleep(250);}
 check(await evaluate(`menu==='stories'&&!state.running&&!state.speaking`),'Opening another menu pauses driving and narration');
 await evaluate(`navigate('drive');document.querySelector('.toggle-drive').click();send('test')`);
 for(let i=0;i<40;i++){if(await evaluate('state.running&&state.speaking'))break;await sleep(250);}
 adb('shell','input','keyevent','KEYCODE_HOME');await sleep(500);
 adb('shell','am','start','-W','-n','kr.dureon.prototype/.MainActivity');
 await sleep(350);
 check(await evaluate('!state.running&&!state.speaking'),'Going to background stops simulation and narration without auto-resuming');
 socket.close();adb('shell','am','force-stop','kr.dureon.prototype');
 adb('shell','am','start','-W','-n','kr.dureon.prototype/.MainActivity');
 await connect();
 const after=await evaluate(snapshot);
 check(await evaluate('innerWidth>innerHeight'),'App process restart remains in landscape');
 check(after.saveHistory===before.saveHistory,'History persistence preference survives process restart');
 check(JSON.stringify(after.historyStamps)===JSON.stringify(before.saveHistory?before.historyStamps:[]),'Listening history after restart matches selected storage policy');
 check(after.pace===before.pace,'Narration frequency survives process restart');
 check(after.voice===before.voice,'Selected TTS voice survives process restart');
 check(after.theme===before.theme,'Theme survives process restart');
 check(after.volume===before.volume,'Media volume remains unchanged after restart');
 check(await evaluate('!state.running&&!state.speaking'),'Restart leaves simulation and narration stopped');
 writeFileSync(resolve(out,'persistence.json'),JSON.stringify({date:'2026-11-14',passed:checks.length,checks,historySaved:before.saveHistory,historyCountBefore:before.historyStamps.length,historyCountAfter:after.historyStamps.length},null,2));
 console.log(JSON.stringify({passed:checks.length},null,2));
}finally{socket?.close()}
