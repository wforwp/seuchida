import {execFileSync} from 'node:child_process';
import {writeFileSync,mkdirSync} from 'node:fs';
import {resolve} from 'node:path';
const serial=process.argv[2]||'emulator-5560';
const adb=(...a)=>execFileSync('C:/Users/outset/AppData/Local/Android/Sdk/platform-tools/adb.exe',['-s',serial,...a],{encoding:'utf8'}).trim();
const outOption=process.argv.indexOf('--out');
const out=resolve(outOption>=0?process.argv[outOption+1]:'../docs/design/screenshots-v10');mkdirSync(out,{recursive:true});
const pid=adb('shell','pidof','kr.dureon.prototype');adb('forward','tcp:9233',`localabstract:webview_devtools_remote_${pid}`);
const pages=await(await fetch('http://127.0.0.1:9233/json/list')).json();
const socket=new WebSocket(pages.find(p=>p.url.includes('appassets')).webSocketDebuggerUrl);
await new Promise((r,j)=>{socket.onopen=r;socket.onerror=j});
let id=0;const pending=new Map();
socket.onmessage=e=>{const m=JSON.parse(e.data);const p=pending.get(m.id);if(p){pending.delete(m.id);clearTimeout(p.timer);m.error?p.reject(Error(JSON.stringify(m.error))):p.resolve(m.result);}};
const call=(method,params={})=>new Promise((resolve,reject)=>{const n=++id;const timer=setTimeout(()=>reject(Error(method)),10000);pending.set(n,{resolve,reject,timer});socket.send(JSON.stringify({id:n,method,params}));});
const evaluate=async expression=>{const r=await call('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});if(r.exceptionDetails)throw Error(JSON.stringify(r.exceptionDetails));return r.result.value;};
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
async function waitReady(){
 await sleep(200);
 for(let attempt=0;attempt<60;attempt++){
  try{if(await evaluate(`typeof theme!=='undefined' && typeof state!=='undefined' && state && document.querySelector('h1') && document.querySelector('.brand-logo').complete && document.querySelector('.brand-logo').naturalWidth>0`)){await evaluate('document.fonts.ready.then(()=>true)');return;}}catch{}
  await sleep(250);
 }
 throw Error('App did not finish loading after WebView reload');
}
try{
 await call('Page.enable');
 await call('DOM.enable');await call('CSS.enable');
 if(process.argv.includes('--reload')){await call('Page.reload',{ignoreCache:true});await waitReady();}
 console.log(JSON.stringify(await evaluate(`({viewport:[innerWidth,innerHeight],theme,actions:[...document.querySelectorAll('.actions button')].map(b=>({text:b.textContent,x:b.offsetWidth,height:b.offsetHeight,bottom:b.getBoundingClientRect().bottom}))})`)));
 await evaluate('document.fonts.ready.then(()=>true)');
 const doc=await call('DOM.getDocument');
 const title=await call('DOM.querySelector',{nodeId:doc.root.nodeId,selector:'h1'});
 const fonts=await call('CSS.getPlatformFontsForNode',{nodeId:title.nodeId});
 writeFileSync(resolve(out,'rendered-fonts.json'),JSON.stringify(fonts,null,2));
 if(!fonts.fonts.some(f=>f.isCustomFont&&f.familyName.includes('Pretendard')))throw Error('Heading did not render using local Pretendard');
 console.log('PASS actual heading glyphs rendered with local Pretendard');
 if(process.argv.includes('--capture')){
  if(!await evaluate('innerWidth>innerHeight'))throw Error('Rotate the emulator to landscape before capturing landscape review images');
  await evaluate(`send('pause');demoOpen=false;setTheme('dark');filter='전체';selected='bulam';detail=false;navigate('drive')`);await sleep(350);
  for(const [menu,name]of [['drive','01-drive-landscape'],['stories','02-stories-landscape'],['history','03-history-landscape'],['settings','04-settings-landscape']]){
   await evaluate(`navigate('${menu}');window.scrollTo(0,0)`);await sleep(300);
   const shot=await call('Page.captureScreenshot',{format:'png',captureBeyondViewport:false});writeFileSync(resolve(out,name+'.png'),Buffer.from(shot.data,'base64'));
  }
  await evaluate(`setTheme('light');navigate('drive')`);await sleep(250);
  await call('Page.reload',{ignoreCache:true});await waitReady();
  if(!await evaluate(`theme==='light' && document.documentElement.dataset.theme==='light'`))throw Error('Light theme did not survive reload');
  const shot=await call('Page.captureScreenshot',{format:'png',captureBeyondViewport:false});writeFileSync(resolve(out,'05-drive-light.png'),Buffer.from(shot.data,'base64'));
  await evaluate(`setTheme('dark');navigate('drive')`);
  await call('Page.reload',{ignoreCache:true});await waitReady();
  if(!await evaluate(`theme==='dark' && document.documentElement.dataset.theme==='dark'`))throw Error('Dark theme did not survive reload');
  console.log('PASS both themes survive WebView reload');
 }
}finally{socket.close()}
