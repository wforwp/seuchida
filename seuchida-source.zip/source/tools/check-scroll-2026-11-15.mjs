import {execFileSync} from 'node:child_process';
import {writeFileSync,mkdirSync} from 'node:fs';
import {resolve} from 'node:path';
const serial=process.argv[2]||'emulator-5560';
const adb=(...a)=>execFileSync('C:/Users/outset/AppData/Local/Android/Sdk/platform-tools/adb.exe',['-s',serial,...a],{encoding:'utf8'}).trim();
const out=resolve('..','docs','design','screenshots-scroll-2026-11-15');mkdirSync(out,{recursive:true});
const pid=adb('shell','pidof','kr.dureon.prototype');adb('forward','tcp:9232',`localabstract:webview_devtools_remote_${pid}`);
const pages=await(await fetch('http://127.0.0.1:9232/json/list')).json();
const socket=new WebSocket(pages.find(p=>p.url.includes('appassets')).webSocketDebuggerUrl);
await new Promise((r,j)=>{socket.onopen=r;socket.onerror=j});
let n=0;const requests=new Map();
socket.onmessage=e=>{const m=JSON.parse(e.data);if(m.id){const p=requests.get(m.id);if(p){clearTimeout(p.timer);requests.delete(m.id);m.error?p.reject(Error(JSON.stringify(m.error))):p.resolve(m.result);}}};
const call=(method,params={})=>new Promise((resolve,reject)=>{const id=++n;const timer=setTimeout(()=>reject(Error(method)),10000);requests.set(id,{resolve,reject,timer});socket.send(JSON.stringify({id,method,params}));});
const evaluate=async expression=>{const r=await call('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});if(r.exceptionDetails)throw Error(JSON.stringify(r.exceptionDetails));return r.result.value;};
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
try{
 await call('Runtime.enable');
 let result={};
 for(const menu of ['drive','stories','history','settings']){
  await evaluate(`navigate('${menu}')`);await sleep(300);
  result[menu]=await evaluate(`(()=>{const c=document.querySelector('#content');const before=c.scrollTop;c.scrollTop=c.scrollHeight;return {client:c.clientHeight,total:c.scrollHeight,scrollTop:c.scrollTop,bodyScroll:document.scrollingElement.scrollTop,headerTop:document.querySelector('#topbar').getBoundingClientRect().top}})()`);
 }
 await evaluate(`navigate('drive');document.querySelector('.demo-panel').open=true`);await sleep(200);
 result.expanded=await evaluate(`(()=>{const c=document.querySelector('#content');c.scrollTop=c.scrollHeight;return {client:c.clientHeight,total:c.scrollHeight,scrollTop:c.scrollTop,buttons:document.querySelectorAll('.demo-controls button').length}})()`);
 if(result.drive.total>result.drive.client+1 || !['stories','history','settings'].every(k=>result[k].scrollTop>0&&result[k].bodyScroll===0)||result.expanded.scrollTop<=0)throw Error(JSON.stringify(result));
 console.log(JSON.stringify(result));
 await evaluate(`document.querySelector('.demo-panel').open=false;navigate('drive')`);
}finally{socket.close()}
