import {execFileSync} from 'node:child_process';
import {mkdirSync,writeFileSync} from 'node:fs';
import {resolve} from 'node:path';

const serial=process.argv[2]||'emulator-5560';
const adb=(...args)=>execFileSync('C:/Users/outset/AppData/Local/Android/Sdk/platform-tools/adb.exe',['-s',serial,...args],{encoding:'utf8'}).trim();
const out=resolve(process.argv[3]||'../docs/verification/latest');mkdirSync(out,{recursive:true});
let socket,sequence=0,pending=new Map(),exceptions=[];
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
async function connect(){
 const pid=adb('shell','pidof','kr.dureon.prototype');
 adb('forward','tcp:9231',`localabstract:webview_devtools_remote_${pid}`);
 let pages=[];
 for(let i=0;i<30;i++){try{pages=await(await fetch('http://127.0.0.1:9231/json/list')).json();if(pages.length)break;}catch{}await sleep(500);}
 const target=pages.find(p=>p.url.includes('appassets.androidplatform.net'));
 if(!target)throw Error('App WebView not found');
 socket=new WebSocket(target.webSocketDebuggerUrl);
 await new Promise((r,j)=>{socket.onopen=r;socket.onerror=j;});
 socket.onmessage=e=>{const m=JSON.parse(e.data);if(m.id){const p=pending.get(m.id);if(p){pending.delete(m.id);clearTimeout(p.timer);m.error?p.reject(Error(JSON.stringify(m.error))):p.resolve(m.result);}}else if(m.method==='Runtime.exceptionThrown')exceptions.push(m.params);};
 await call('Runtime.enable');await call('Page.enable');
}
function call(method,params={}){return new Promise((resolve,reject)=>{const id=++sequence;const timer=setTimeout(()=>{pending.delete(id);reject(Error(`Timeout: ${method}`));},15000);pending.set(id,{resolve,reject,timer});socket.send(JSON.stringify({id,method,params}));});}
async function evaluate(expression){const r=await call('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});if(r.exceptionDetails)throw Error(JSON.stringify(r.exceptionDetails));return r.result.value;}
async function wait(expression,label){for(let i=0;i<40;i++){if(await evaluate(expression))return;await sleep(400);}throw Error(`Timed out: ${label}`);}
async function click(selector){await evaluate(`document.querySelector(${JSON.stringify(selector)}).click()`);await sleep(300);}
async function shot(name){await sleep(250);const r=await call('Page.captureScreenshot',{format:'png',captureBeyondViewport:false});writeFileSync(resolve(out,name+'.png'),Buffer.from(r.data,'base64'));}
const checks=[];
async function check(expression,label){if(!await evaluate(expression))throw Error(label);checks.push(label);console.log('PASS '+label);}

try{
 await connect();
 await wait(`typeof state!=='undefined' && state && document.querySelector('h1')`,'initial UI');
 adb('shell','settings','put','system','accelerometer_rotation','0');adb('shell','settings','put','system','user_rotation','0');
 await wait('innerWidth>innerHeight','landscape lock with portrait device setting');
 const initialSettings=await evaluate('({saveHistory:state.saveHistory,pace:state.pace,historyCount:state.history.length})');
 await check(`document.querySelectorAll('.nav-item').length===4`,'Four working menu entries');
 await check(`getComputedStyle(document.querySelector('.rail')).position==='fixed'`,'Packaged stylesheet loaded');
 await check(`document.fonts.ready.then(()=>[...document.fonts].some(f=>f.family==='Pretendard'&&f.status==='loaded')&&document.fonts.check('16px Pretendard','스치다 이야기'))`,'Local Pretendard font loaded for Korean text');
 await check(`document.querySelector('.brand-logo').complete && document.querySelector('.brand-logo').naturalWidth>0`,'Local vector brand logo loaded');
 await check('innerWidth>innerHeight','App launches in landscape with portrait device setting');
 await check(`document.documentElement.scrollWidth<=innerWidth+1`,'Landscape launch has no horizontal overflow');
 await shot('01-drive-on-launch');
 await click('[data-nav="stories"]');
 await click('[data-filter="강과 다리"]');
 await check(`document.querySelectorAll('.scene-tile').length===1 && document.querySelector('.scene-tile strong').textContent==='중랑천'`,'Story category filter selects the river');
 await click('.story-tab[data-detail="true"]');
 await check(`document.querySelector('.story-script').textContent===state.scenes.find(s=>s.id==='stream').detail`,'Detailed story switches to registered script');
 await wait('state.ttsReady','Korean TTS engine');
 const stamp=await evaluate('state.history[0]?.stamp||0');
 await click('[data-action="preview"]');
 await wait(`state.history[0]?.stamp>${stamp}`,'actual TTS start creates listening history');
 await check(`state.history[0].id==='stream'`,'History records the selected place');
 await click('[data-action="stop"]');
 await wait('!state.speaking','immediate narration stop');
 await click('[data-nav="history"]');
 await check(`document.querySelectorAll('.history-item').length===state.history.length`,'History screen renders actual listening entries');
 await click('[data-nav="settings"]');
 const initialTheme=await evaluate('theme');
 await click('[data-theme-choice="light"]');
 await check(`document.documentElement.dataset.theme==='light' && localStorage.getItem('seuchida-theme')==='light'`,'Light theme selected and persisted');
 await click('[data-theme-choice="dark"]');
 await check(`document.documentElement.dataset.theme==='dark' && localStorage.getItem('seuchida-theme')==='dark'`,'Dark theme selected and persisted');
 await click(`[data-theme-choice="${initialTheme}"]`);
 await check(`document.querySelectorAll('#voice option').length===state.voices.length`,'Voice selector uses installed Korean voices');
 await click('[data-action="test"]');
 await wait(`state.speaking && state.speechState==='이야기 재생 중'`,'settings voice preview actually starts');
 await check('state.ttsReady && state.speaking','Settings voice preview starts in Korean TTS engine');
 await evaluate(`send('stop')`);await wait('!state.speaking','settings voice preview stops');
 await evaluate(`document.querySelector('[data-setting="saveHistory"]').checked=true;document.querySelector('[data-setting="saveHistory"]').dispatchEvent(new Event('change',{bubbles:true}))`);
 await wait('state.saveHistory','history persistence setting');
 await click('[data-pace="often"]');await wait(`state.pace==='often'`,'narration frequency preference');
 const originalVolume=await evaluate('state.volume');
 const changedVolume=originalVolume===0?1:originalVolume-1;
 await evaluate(`document.querySelector('#volume').value=${changedVolume};document.querySelector('#volume').dispatchEvent(new Event('change',{bubbles:true}))`);
 await wait(`state.volume===${changedVolume}`,'real Android volume control');
 await evaluate(`document.querySelector('#volume').value=${originalVolume};document.querySelector('#volume').dispatchEvent(new Event('change',{bubbles:true}))`);
 await wait(`state.volume===${originalVolume}`,'volume restored');
 await click('[data-nav="drive"]');
 await click('.demo-panel summary');
 await click('[data-action="reset"]');
 const speedSelections=[];
 for(const speed of [0,30,60,100]){await click(`[data-action="speed"][data-value="${speed}"]`);await wait(`state.speed===${speed}`,'simulation speed selection');speedSelections.push(speed);}
 await check(`state.speed===100 && ${speedSelections.length}===4`,'All four simulation speed choices update native state');
 await click('[data-action="speed"][data-value="0"]');await click('[data-action="toggle"]');await sleep(900);
 await check('state.running && state.position===0 && !state.current','Zero-speed simulation does not move or announce scenery');
 await click('[data-action="toggle"]');
 await click('[data-action="reset"]');await click('[data-action="speed"][data-value="100"]');await click('[data-action="toggle"]');
 await wait(`state.position>0 && state.running`,'live simulation movement');
 await wait(`state.current==='bulam' && state.history[0].id==='bulam'`,'speed-based automatic narration');
 await click('[data-action="toggle"]');await wait('!state.running && !state.speaking','pause stops simulation and speech');
 const beforeMore=await evaluate('state.history[0]?.stamp||0');
 await click('[data-action="more"]');
 await wait(`state.history[0]?.stamp>${beforeMore} && state.speaking`,'more narration starts');
 await check(`state.current==='bulam' && state.history[0].id==='bulam'`,'More narration starts for current landscape');
 await click('[data-action="stop"]');await wait('!state.speaking','more narration stops');
 const beforeReplay=await evaluate('state.history[0]?.stamp||0');
 await click('[data-action="replay"]');
 await wait(`state.history[0]?.stamp>${beforeReplay} && state.speaking`,'replay narration starts');
 await check(`state.current==='bulam' && state.history[0].id==='bulam'`,'Replay narration starts for current landscape');
 await click('[data-action="stop"]');await wait('!state.speaking','replay narration stops');
 await click('[data-action="direction"]');await wait('!state.forward && !state.current','direction change invalidates current scenery');
 await click('[data-action="reset"]');await click('[data-action="toggle"]');
 await wait(`state.current==='surak' && state.history[0].id==='surak' && state.position<2400`,'reverse automatic narration');
 await check(`!state.forward && state.current==='surak'`,'Reverse route automatically announces the landscape ahead');
 await click('[data-action="toggle"]');await wait('!state.running&&!state.speaking','reverse simulation paused');
 await click('[data-action="direction"]');await click('[data-action="reset"]');
 await click('[data-action="speed"][data-value="60"]');
 // Rotate the actual emulator; the WebView retains its session across rotations.
 adb('shell','settings','put','system','accelerometer_rotation','0');adb('shell','settings','put','system','user_rotation','2');
 await sleep(1500);
 await wait(`innerWidth>innerHeight && state && state.history.length>0`,'landscape session continuity');
 await check(`state.saveHistory && state.pace==='often'`,'preferences survive screen rotation');
 await check('innerWidth>innerHeight','Landscape lock remains active with reverse portrait device setting');
 await check(`document.documentElement.scrollWidth<=innerWidth+1`,'Landscape layout has no horizontal overflow');
 await check(`[...document.querySelectorAll('.actions button')].every(b=>{const r=b.getBoundingClientRect();return r.height>=48 && r.width>=48 && r.top>=0 && r.bottom<=innerHeight})`,'All primary landscape controls visible with 48px touch targets');
 await shot('01-drive-landscape');
 for(const [id,name] of [['stories','02-stories-landscape'],['history','03-history-landscape'],['settings','04-settings-landscape']]){await click(`[data-nav="${id}"]`);await shot(name);}
 // Never remove listening records that existed before this test.
 await evaluate(`send('saveHistory',{value:${initialSettings.saveHistory}});${initialSettings.historyCount===0?"send('clearHistory');":''}send('pace',{value:${JSON.stringify(initialSettings.pace)}});navigate('drive')`);
 await wait(`state.saveHistory===${initialSettings.saveHistory} && state.pace===${JSON.stringify(initialSettings.pace)}`,'settings restored');
 if(exceptions.length)throw Error(`JavaScript exceptions: ${JSON.stringify(exceptions)}`);
 adb('shell','settings','put','system','user_rotation','0');
 checks.push('No JavaScript runtime errors');
 writeFileSync(resolve(out,'verification.json'),JSON.stringify({checks,exceptions},null,2));
 console.log(JSON.stringify({passed:checks.length,checks,screenshots:out},null,2));
}finally{socket?.close();}
